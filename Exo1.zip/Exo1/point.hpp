#ifndef POINT_HPP
#define POINT_HPP

#include <iostream>

class Point
{
private:
    double x;
    double y;

public:

    Point();
    Point(double x, double y);


    double getX() const;
    double getY() const;

    Point operator+(const Point& other) const;
    Point operator-(const Point& other) const;
    bool operator==(const Point& other) const;
    Point& operator=(const Point& other);


    bool operator!=(const Point& other) const;
    Point& operator+=(const Point& other);
    Point& operator-=(const Point& other);


    friend std::ostream& operator<<(std::ostream& os, const Point& p);
    friend std::istream& operator>>(std::istream& is, Point& p);
};

#endif
