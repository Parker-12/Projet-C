#include <iostream>
#include "Point.hpp"

int main()
{

    Point p1;
    Point p2(2.5, 7);


    Point p3;
    std::cout << "Entrer les coordonnees du point p3 (x y): ";
    std::cin >> p3;


    std::cout << "p1 = " << p1 << std::endl;
    std::cout << "p2 = " << p2 << std::endl;
    std::cout << "p3 = " << p3 << std::endl;


    Point somme = p2 + p3;
    Point diff = p2 - p3;
    std::cout << "p2 + p3 = " << somme << std::endl;
    std::cout << "p2 - p3 = " << diff << std::endl;


    std::cout << "(p2 == p3) = " << (p2 == p3) << std::endl;


    Point p4;
    p4 = p2;
    std::cout << "p4 apres affectation = " << p4 << std::endl;


     p4 = p4;

    return 0;
}
