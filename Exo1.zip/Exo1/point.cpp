#include "Point.hpp"


Point::Point() : x(0.0), y(0.0) {}


Point::Point(double x, double y) : x(x), y(y) {}


double Point::getX() const
{
    return x;
}

double Point::getY() const
{
    return y;
}


Point Point::operator+(const Point& other) const
{
    return Point(x + other.x, y + other.y);
}


Point Point::operator-(const Point& other) const
{
    return Point(x - other.x, y - other.y);
}


bool Point::operator==(const Point& other) const
{
    return x == other.x && y == other.y;
}


Point& Point::operator=(const Point& other)
{
    if (this != &other)
    {
        x = other.x;
        y = other.y;
    }
    return *this;
}


bool Point::operator!=(const Point& other) const
{
    return !(*this == other);
}

Point& Point::operator+=(const Point& other)
{
    x += other.x;
    y += other.y;
    return *this;
}

Point& Point::operator-=(const Point& other)
{
    x -= other.x;
    y -= other.y;
    return *this;
}


std::ostream& operator<<(std::ostream& os, const Point& p)
{
    os << "(" << p.x << ", " << p.y << ")";
    return os;
}


std::istream& operator>>(std::istream& is, Point& p)
{
    is >> p.x >> p.y;
    return is;
}

